<?php
mysql_connect("localhost","root","") or die("gagal connect server");
mysql_select_db("db_identitas") or die("gagal connect database");

session_start();
$_SESSION['username'];
?>
<html>
<head>
	<title>Belajar Material Design</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link rel="stylesheet" type="text/css" href="conf/css/materialize.min.css"/>

<style>
.bjn{
	margin-left: 350px;
	
}
.bijan{
	margin:0 355px !important;
}
.row{
	margin-top:4%; 
}
.ava{
	padding-top: 7px;
}
.nun{
	width:300px;
}
.wong{
height:30px !important;
margin:0px !important;
}
.wing{
padding:10px;
}
input{
	margin-top: -15px !important; 
}
.ko{
	margin-top: 5px;
}
.bjnbtn{
	margin-top:10px;
}
</style>
</head>

<body>
<ul id="bjndropdown" class="dropdown-content olo" style="margin-top:64px;">
			<li><a href="#" class="lolo"><?php 
			$username = $_SESSION['username'];
			if( !isset($_SESSION['username']))
			{
			echo "not found";
			header('location:invald.php');
			}
			else{
			mysql_connect("localhost","root","") or die("gagal");
			mysql_select_db("db_identitas") or die("gagal");
			$sql = mysql_query("SELECT * FROM tabel_guru WHERE username=\"$username\"");
			while($row=mysql_fetch_array($sql)){
				echo $_SESSION['username']."<p class=\"jan\">(".$row['nama'].")</p>";
			}
			}
			?>
			</a>
			</li>
			<li><a href="#">cantik</a></li>
			<li><a href="logout.php">logout</a></li>
		</ul>
<nav>
	<div class="top-nav fixed">
		<a href="panel.php" class="brand-logo bjn hide-on-med-and-down" >Bijan cantik</a>
		<a href="panel.php" class="brand-logo center show-on-med-and-down hide-on-large-only"  >Bijan cantik</a>
		<a href="#" data-activates="mobile-menu" class="button-collapse">
			<img class="ava" src="more_wh.png"></img>
		</a>
		<a href="#" class="right ava dropdown-button" data-activates="bjndropdown"><img src="ava.png"></a>
</div>

	<div class="side-nav fixed">
	<ul class="left hide-on-med-and-down">
			<li>&nbsp;</li>
			<li>&nbsp;</li>
			<li class="nun"><a href="lihat%20data.php">Lihat Data</a></li>
		</ul>
	</div>
	<ul class="side-nav left" id="mobile-menu">
			<li>&nbsp;</li>
			<li>&nbsp;</li>
			<li><a href="lihat%20data.php">Lihat Data</a></li>
		</ul>
	</nav> 	
	<div class="container bijan show-on-large-and-med-only hide-on-med-and-down">
		<h3 align="left">Input Nilai Siswa</h3>
		<ul class="collection">
			<li class="collection-item">
				<div class="row wong">
					<div class="col s3 m3 l3">
						NIS
					</div>
					<div class="col s3 m3 l3">
						Nama
					</div>
					<div class="col s3 m3 l3">
						Kelas
					</div>
					<div class="col s3 m3 l3">
						Nilai
					</div>
				</div>
			</li>
			<form action="nilai.php?mapel=<?php echo $_GET['mapel']?>" method="post">
						<?php
						mysql_connect("localhost","root","") or die("gagal connect database");
mysql_select_db("db_identitas") or die("gagal menghubungi databasse");
$query = mysql_query("SELECT * FROM tabel_nilai order by nis asc");
$o=  mysql_num_rows($query);
			$i=0;
			while($row=mysql_fetch_array($query)){
			echo "<li class=\"collection-item\">";
				echo "<div class=\"row wong\">";
					echo "<div class=\"col s3 m3 l3 ko\">";
						echo $row['nis'];
					echo "</div>";
					echo "<div class=\"col s3 m3 l3 ko\">";
						echo $row['nama'];
					echo "</div>";
					echo "<div class=\"col s3 m3 l3 ko\">";
						echo $row['kelas'];
					echo "</div>";
					$var= $_GET['mapel'];
					echo "<div class=\"col s3 m3 l3\">";
					echo "<input type=\"text\" placeholder=\"nilai\" name='nilai[$i]' value='".$row[$var]."' />";
					echo "<input type=\"hidden\" name=\"nis[$i]\" value='".$row['nis']."' />";
					echo "</div>";
				echo "</div>";
			echo "</li>";
++$i;
		};
			?>
			<div class="bjnbtn left">
			<li class="collection-item">
				<input type="submit" value="submit" class="btn ko">
			</li>
			</div>
			</form>
		</ul>
	</div>
		<div class="container show-on-small-only hide-on-large-only">
		<h3 align="right">Input Nilai Siswa</h3>
		<ul class="collection">
			<li class="collection-item">
				<div class="row wong">
					<div class="col s6 m6 l6">
						Nama
					</div>
					<div class="col s6 m6 l6">
						Nilai
					</div>
				</div>
			</li>
			<form action="nilai.php?mapel=<?php echo $_GET['mapel']?>" method="post">
						<?php
						mysql_connect("localhost","root","") or die("gagal connect database");
mysql_select_db("db_identitas") or die("gagal menghubungi databasse");
$query = mysql_query("SELECT * FROM tabel_nilai order by nis asc");
$o=  mysql_num_rows($query);
			$i=0;
			while($row=mysql_fetch_array($query)){
			echo "<li class=\"collection-item\">";
				echo "<div class=\"row wong\">";
					echo "<div class=\"col s6 m6 l6 ko\">";
						echo $row['nama'];
					echo "</div>";
					$var = $_GET['mapel'];
					echo "<div class=\"col s6 m6 l6\">";
					echo "<input type=\"text\" placeholder=\"nilai\" name='nilai[$i]' value='".$row[$var]."' />";
					echo "<input type=\"hidden\" name=\"nis[$i]\" value='".$row['nis']."' />";
					echo "</div>";
				echo "</div>";
			echo "</li>";
++$i;
		};
			?>
		<div class="bjnbtn left">
			<li class="collection-item">
				<input type="submit" value="submit" class="btn ko">
			</li>
			</div>
			<li class="collection-item"></li>
			</form>
		</ul>
	</div>
	<footer class="page-footer" style="height:200px;">
	<div class="container bijan show-on-large-only hide-on-med-and-down">
		<div class="row">
			<div class="col s4 l6 m6">
			bijan
			</div>
			<div class="col s4 l6 m6">
			cantik
			</div>
		</div>
	</div>
	<div class="container show-on-med-and-down hide-on-large-only">
		<div class="row">
			<div class="col s4 l6 m6">
			bijan
			</div>
			<div class="col s4 l6 m6">
			cantik
			</div>
		</div>
	</div>
</footer>
		<script src="conf/js/jquery-3.0.0.min.js"></script>
		<script src="conf/js/materialize.min.js"></script>
		<script>
			$(document).ready(function(){
				$('.button-collapse').sideNav('');
			});
		</script>
		<?php
		if ($err =="wongko"){
		echo "<script>";
		echo "Materialize.toast('Nilai Sudah diupdate !', 4000);";
		echo "</script>";
		}
		else{
			session_destroy($err);
		}
		?>
</body>
</html>