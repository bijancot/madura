<?php

echo md5("bamz1");
?>