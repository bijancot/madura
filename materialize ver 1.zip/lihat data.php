<html>
<?php
mysql_connect("localhost","root","") or die("gagal connect server");
mysql_select_db("db_identitas") or die("gagal connect database");


$sql=mysql_query('SELECT * FROM tabel_siswa ORDER BY nis asc');

session_start();
$_SESSION['username'];
?>
<head>
	<title>Belajar Material Design</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link rel="stylesheet" type="text/css" href="conf/css/materialize.min.css"/>

<style>
.bjn{
	margin-left: 350px;
}
.bijan{
	margin:0 355px !important;
}
.row{
	margin-top:4%; 
}
.ava{
	padding-top: 7px;
}
.nun{
	width:300px;
}
.wong{
height:30px !important;
margin:0px !important;
}
.wing{
padding-left:20px;
}
.jan{
	font-size: 0.75em;
}
.olo{
	width:200px !important;
}
.lolo{
	font-size: 1em !important;
}
.bi{
	padding-left:40px;
	#margin-top:-10px !important;
	border: 1px dashed black;
}
.size1{
	font-size:20px;
}
</style>
</head>

<body>
<ul id="bjndropdown" class="dropdown-content olo" style="margin-top:64px;">
			<li><a href="#" class="lolo"><?php 
			$username = $_SESSION['username'];
			if( !isset($_SESSION['username']))
			{
			echo "not found";
			header('location:invald.php');
			}
			else{
			mysql_connect("localhost","root","") or die("gagal");
			mysql_select_db("db_identitas") or die("gagal");
			$sql = mysql_query("SELECT * FROM tabel_guru WHERE username=\"$username\"");
			while($row=mysql_fetch_array($sql)){
				echo $_SESSION['username']."<p class=\"jan\">(".$row['nama'].")</p>";
			}
			}
			?>
			</a>
			</li>
			<li><a href="#">cantik</a></li>
			<li><a href="logout.php">logout</a></li>
		</ul>
<nav>
	<div class="top-nav fixed">
		<a href="panel.php" class="brand-logo bjn hide-on-med-and-down" >Bijan cantik</a>
		<a href="panel.php" class="brand-logo center show-on-med-and-down hide-on-large-only"  >Bijan cantik</a>
		<a href="#" data-activates="mobile-menu" class="button-collapse">
			<img class="ava" src="more_wh.png"></img>
		</a>
		<a href="#" class="right ava dropdown-button" data-activates="bjndropdown"><img src="ava.png"></a>
</div>

	<div class="side-nav fixed">
	<ul class="left hide-on-med-and-down">
			<li>&nbsp;</li>
			<li>&nbsp;</li>
			<li class="nun"><a href="lihat%20data.php">Lihat Data</a></li>
	</ul>
	</div>
	<ul class="side-nav left" id="mobile-menu">
			<li>&nbsp;</li>
			<li>&nbsp;</li>
			<li><a href="lihat%20data.php">Lihat Data</a></li>
		</ul>
	</nav> 	
		<div class="container bijan show-on-large-only hide-on-med-and-down">
	<ul class="collapsible" data-collapsible="expandable">
    <li class="header">
	<div class="row wing">
		<div class="col s12 m12 l4">
			Nama
		</div>
		<div class="col s12 m12 l4">
			NISN
		</div>
		<div class="col s12 m12 l4">
			Kelas
		</div>
	</div>
	<hr/>
	</li>
	<?php
	mysql_connect("localhost","root","") or die("gagal connect server");
mysql_select_db("db_identitas") or die("gagal connect database");
$sql=mysql_query('SELECT * FROM tabel_siswa ORDER BY nis asc');

	while($row=mysql_fetch_array($sql)){
	echo "<li>";
     echo "<div class=\"collapsible-header\">";
	  echo "<div class=\"row wong\">";
	  echo "<div class=\"col s4 m4 l4\">";
	  echo $row['nama'];
	  echo "</div>";
	  echo "<div class=\"col s4 m4 l4\">";
	  echo $row['nis'];
	  echo "</div>";
	  echo "<div class=\"col s4 m4 l4\">";
	  echo $row['kelas'];
	  echo "</div>";
	  echo "</div>";
	  echo "</div>";
       echo "<div class=\"collapsible-body\">";
      		echo "<div class=\"row bi\">";
      			echo "<div class= \"col s4 m4 l4 bi size1\">";
      				echo "<ul>";
      					echo "<li>";
      					echo "Nilai Produktif";
      					echo "</li>";
      					echo "<li>";
      					echo "100";
      					echo "</li>";
      					echo "<li>";
      					echo "100";
      					echo "</li>";
      					echo "<li>";
      					echo "100";
      					echo "</li>";
      					echo "<li>";
      					echo "100";
      					echo "</li>";
      				echo "</ul>";
      			echo "</div>";
      			echo "<div class= \"col s4 m4 l4 bi size1\">";
      				echo "<ul>";
      					echo "<li>";
      					echo "Nilai Pelajaran wajib";
      					echo "</li>";
      					echo "<li>";
      					echo "100";
      					echo "</li>";
      					echo "<li>";
      					echo "100";
      					echo "</li>";
      					echo "<li>";
      					echo "100";
      					echo "</li>";
      				echo "</ul>";
      			echo "</div>";
      			echo "<div class= \"col s4 m4 l4\">";
      			echo "3";
      			echo "</div>";
	      		echo "</div>";
      echo "</div>";
	  echo "</li>";
	};
	?>
  </ul> 	
  </div>
	<div class="container show-on-med-and-down hide-on-large-only">
	<ul class="collapsible " data-collapsible="expandable">
	 <li class="header">
	<div class="row wong">
		<div class="col s4 m4 l4">
			Nama
		</div>
		<div class="col s4 m4 l4">
			NISN
		</div>
		<div class="col s4 m4 l4">
			Kelas
		</div>
	</div>
	<hr/>
	</li>
	<?php
	mysql_connect("localhost","root","") or die("gagal connect server");
mysql_select_db("db_identitas") or die("gagal connect database");
$sql=mysql_query('SELECT * FROM tabel_nilai ORDER BY nis asc');

	while($row=mysql_fetch_array($sql)){
	echo "<li>";
     echo "<div class=\"collapsible-header\">";
	  echo "<div class=\"row wong\">";
	  echo "<div class=\"col s4 m4 l4\">";
	  echo $row['nama'];
	  echo "</div>";
	  echo "<div class=\"col s4 m4 l4\">";
	  echo $row['nis'];
	  echo "</div>";
	  echo "<div class=\"col s4 m4 l4\">";
	  echo $row['kelas'];
	  echo "</div>";
	  echo "</div>";
	  echo "</div>";
      echo "<div class=\"collapsible-body\">";
      		echo "<div class=\"row wong\">";
      			echo "<div class= \"col s4 m4 l4\">";
      			echo "1";
      			echo "</div>";
      			echo "<div class= \"col s4 m4 l4\">";
      			echo "2";
      			echo "</div>";
      			echo "<div class= \"col s4 m4 l4\">";
      			echo "3";
      			echo "</div>";
	      		echo "</div>";
      echo "</div>";
	  echo "</li>";
	};
	?>
  </ul> 	
  </div>
 <footer class="page-footer" style="height:200px;">
	<div class="container bijan show-on-large-only hide-on-med-and-down">
		<div class="row">
			<div class="col s4 l6 m6">
			bijan
			</div>
			<div class="col s4 l6 m6">
			cantik
			</div>
		</div>
	</div>
	<div class="container show-on-med-and-down hide-on-large-only">
		<div class="row">
			<div class="col s4 l6 m6">
			bijan
			</div>
			<div class="col s4 l6 m6">
			cantik
			</div>
		</div>
	</div>
</footer>
		<script src="conf/js/jquery-3.0.0.min.js"></script>
		<script src="conf/js/materialize.min.js"></script>
		<script>
			$(document).ready(function(){
				$('.button-collapse').sideNav('');
			});
		</script>
</body>
</html>